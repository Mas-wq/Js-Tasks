const ourMath = require("./test.js");

let testvalue = ourMath.avg(2, 3, 2, 3, 4, 5, 6, 7, 8, 9, 9, 12, 3, 24, 2);
console.log(testvalue);
// unit test for avg function
if (testvalue === 6.6) {
  console.log("avg function works correctly");
} else {
  console.log("avg function is broken");
}

let uniontest = ourMath.union([1, 2, 3], [2, 3, 4]);
console.log(uniontest);

//unit test for union function

if (
  uniontest[0] == 1 &&
  uniontest[1] == 2 &&
  uniontest[2] == 3 &&
  uniontest[3] == 4
) {
  console.log("union function works correctly");
} else {
  console.log("union function is broken");
}

let intersectiontest = ourMath.intersection([1, 2, 3], [2, 3, 4]);
console.log(intersectiontest);

//unit test for intersection function
if (intersectiontest[0] == 2 && intersectiontest[1] == 3) {
  console.log("intersection function works correctly");
} else {
  console.log("intersection function is broken");
}

// unit test for max function
let maxtest = ourMath.max(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
console.log(maxtest);
if (maxtest === 15) {
  console.log("max function works correctly");
} else {
  console.log("max function is broken");
}
