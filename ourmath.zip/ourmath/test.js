/*
1- create a average function
2-input: ...numbers (number[]) 
3- sum all numbers and divide by count of numbers
4- output: number

*/
exports.avg = function avg(...nums) {
  let result = 0;
  for (i = 0; i < nums.length; i++) {
    result += nums[i];
  }
  result /= nums.length;
  return result;
};

/*
 union of two sets 
inputs: first_set , second_set
steps:
1- create a function that takes two sets as input
2-Create a new set called union_set
3- copy all elements rom frist_set to union_set
4-copy all elements from second_set to union_set but only elements not included in frist_set
5- return union_set

*/
exports.union = function union(frist_set, second_set) {
  let union_set = [];
  for (i = 0; i < frist_set.length; i++) {
    union_set.push(frist_set[i]);
  }
  for (i = 0; i < second_set.length; i++) {
    if (union_set.includes(second_set[i])) {
      continue;
    }
    union_set.push(second_set[i]);
  }

  return union_set;
};

/*
intersection of two sets
inputs: first_set , second_set    
steps:
1- for each element in frist_set 
   - if the element is included in second_set
     - add it to result

*/

exports.intersection = function intersection(frist_set, second_set) {
  let result = [];
  for (i = 0; i < frist_set.length; i++) {
    if (second_set.includes(frist_set[i])) {
      result.push(frist_set[i]);
    }
  }
  return result;
};

/*
Max
inputs: ...nums
steps:
-temp varaible max =The smallest number value
  - for each item in nums
   -if item>max
     then max=item
     return max
*/

exports.max = function max(...nums) {
  let max = Number.NEGATIVE_INFINITY;
  for (i = 0; i < nums.length; i++) {
    if (nums[i] > max) {
      max = nums[i];
    }
  }
  return max;
};
