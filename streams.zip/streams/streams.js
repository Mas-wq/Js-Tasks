
const fs = require ("fs");
const file_name = "customer_data.txt";
let reader=fs.createReadStream(file_name,{
    encoding : "utf8" ,
    highWaterMark: 6 // number of character that will be read for one time => defalut 64 kB
});
reader.on("data",(chunk)=>{
    console.log(chunk);
    console.log("======================");
});
reader.on("error",(err)=>{
console.log(err);
});
reader.on("close",()=>{
    console.log("Read stream is end");
    });

/*
         //====================Read file stream => used for large files and reads file part by part. ====================//
 =>[1]
|-----------------------------------------------------| =>
|         let reader = fs.createReadStream(file_name);| =>   :السطر ده بيعمل حاجة مهمة جدًا
|-----------------------------------------------------| =>

 => مش بيقرأ الملف كله مره واحدة
 => يعني لو ملف حجمه جيجا مش هيحط الجيجا دي كلها في ميموري مره واحدة
 => بدل كده بيقرأ ملف حتة حتة
 => chunk كل حتة من البيانات دي اسمها

  reader =>  object [ not event ]
  reader =>  ReadStream => EventEmitter
=>[2]
|--------------------------------------------------| =>
|    reader.on('data', (chunk) => {                | =>     ركز كود ده مهم اوي
|    console.log(chunk);});                        | =>
|--------------------------------------------------| =>

=> Reader هنا انت بتقول يا
=> event لو حصل عندك
=> data واسمه كان
=> نفذ كود ده
=> listener وده اسمه




 */